
document.addEventListener('DOMContentLoaded', () => {
    console.log("Welcome to Citizenship Study Tool!");
});
    